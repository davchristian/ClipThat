# ClipThat — Plugin lokal UI/UX Desktop

Paket ini membangun **24 layar utama, 20 dialog, dan 45 variasi kondisi** di Figma Design. Semua layar aplikasi berukuran desktop 1440 × 1000 px dengan konten yang dapat digulir. Dialog mengikuti ukuran kontennya.

File tujuan: **[ClipThat — UI/UX Desktop](https://www.figma.com/design/MzuPBWCaHylLmsdLu67CLm)**, di Davin Farel Santoso's team.

## Jalankan di Figma

1. Pasang dan buka [Figma desktop untuk Windows](https://www.figma.com/downloads/), kemudian masuk dengan akun Figma yang sama. Plugin development diimpor melalui aplikasi desktop.
2. Buka file tujuan di atas melalui aplikasi desktop. Pastikan berada di mode **Design** dan memiliki akses mengedit.
3. Buka menu Figma → **Plugins → Development → Import plugin from manifest…** (pada versi tertentu tertulis “Import new plugin from manifest…”).
4. Pilih `manifest.json` dari folder ini. Jika memakai ZIP, ekstrak dahulu; `manifest.json`, `code.js`, dan `ui.html` harus tetap dalam folder yang sama.
5. Buka **Plugins → Development → ClipThat — UI/UX Desktop**.
6. Klik **Buat UI/UX ClipThat**, lalu tunggu sampai selesai. Jangan menutup plugin saat proses berjalan.
7. Setelah berhasil, klik **Unduh laporan hasil**, lalu **Tutup**. Laporan berisi ID layar, font aktual, jumlah koneksi, dan bagian yang perlu diperiksa.
8. Gunakan **Present / tombol ▶** di Figma. Pilih flow **ClipThat · Mahasiswa**, **ClipThat · Dosen**, atau **ClipThat · Skenario**.

### Jika pilihan Mahasiswa/Dosen di Present tidak membuka layar

1. Keluar dari Present, lalu jalankan lagi **Plugins → Development → ClipThat — UI/UX Desktop** dari halaman yang berisi desain.
2. Klik **Perbaiki flow Present yang sudah dibuat**. Perintah ini hanya memasang ulang dua tombol Cover dan tiga flow Present; layar yang ada tidak dibuat ulang atau dihapus.
3. Setelah status sukses, buka Present lagi dan pilih flow **ClipThat · Mahasiswa**. Alternatifnya, dari kanvas klik tombol **Mulai sebagai mahasiswa** pada frame **ClipThat UIUX 1.0 / Cover**.
4. Jika flow tetap tidak muncul, pastikan plugin berjalan di halaman yang sama dengan frame ClipThat. Plugin menampilkan pesan jika frame awal tidak ditemukan.

### Tampilkan seluruh layar di kanvas

Jalankan plugin dari halaman yang berisi desain, lalu klik **Tampilkan semua layar sebagai grid**. Plugin menata semua frame layar yang sudah dibuat dalam lima kolom dan men-zoom kanvas ke seluruh kumpulan. Ini hanya mengubah posisi frame layar; koneksi prototype tetap terpasang.

Jika menggunakan folder workspace langsung, manifest ada di:

```text
C:\Users\davin\OneDrive\Documents\VS code\ClipThat\src\concept\uiux\plugin\manifest.json
```

Tidak perlu Node.js, terminal, npm, API key, atau upgrade berbayar untuk menjalankan paket yang sudah dibangun ini. Plugin tidak membuat koneksi jaringan sendiri dan tidak menjalankan API AI berbayar.

## Jika Figma meminta ID plugin

Manifest memakai ID lokal untuk development, bukan ID publik Figma. Bila instalasi Figma meminta ID yang diterbitkan oleh Figma:

1. Pilih **Plugins → Development → New Plugin…**, beri nama `ClipThat UIUX`, pilih **Figma Design** dan template **Custom UI**, kemudian simpan ke folder baru.
2. Salin `code.js` dan `ui.html` dari paket ini ke folder plugin baru itu.
3. Pada `manifest.json` yang dibuat Figma, **pertahankan nilai `id` dari Figma**. Pastikan `main` bernilai `code.js`, `ui` bernilai `ui.html`, `editorType` bernilai `["figma"]`, `documentAccess` bernilai `"dynamic-page"`, dan `networkAccess` bernilai `{ "allowedDomains": ["none"] }`. Hapus properti `build` bila template menambahkannya; file JavaScript paket ini sudah siap dijalankan.
4. Jalankan plugin baru dari menu Development. Tidak perlu memublikasikannya ke Community.

## Yang dibuat

- Cover dengan tombol mulai untuk kedua peran.
- Fondasi warna oat cream, ivory, muted forest, sage, dan peach; 61 variables termasuk primitive/semantic colors, spacing, dan radius; 8 text styles.
- Komponen Button (4 gaya × 5 keadaan), Badge (3), dan Field (2), dengan properti teks. Panel, navigasi, kartu, dan isi halaman memakai auto-layout serta layer teks/ikon yang dapat diedit.
- 24 layar utama mahasiswa dan dosen, ditambah 65 dialog/variasi keadaan untuk mencoba alur.
- Koneksi klik antar-layar, dialog, dan indeks skenario. Buka hasil melalui flow prototype.
- Font Nunito Sans bila tersedia, kemudian DM Sans, Arial, atau Inter sesuai font Regular/Bold yang tersedia. Font aktual dicatat di laporan.

Plugin bekerja pada halaman yang sedang dibuka dan meletakkan hasil di sebelah kanan konten yang sudah ada. Konten sebelumnya tidak dihapus. Jika desain ClipThat sudah ada pada halaman itu, pembuatan ulang ditolak agar tidak menggandakan hasil; gunakan halaman kosong untuk versi baru.

## Yang dicoba dalam prototype

- Mahasiswa: bergabung, mengikuti transkrip, Capture 90 detik, bookmark, draf pertanyaan, dukungan anonim, foto, catatan, review materi sebelumnya, peta materi, agenda, integrasi, dan penghapusan pribadi.
- Dosen: menyiapkan sesi, unggah materi, mikrofon, mulai/akhiri kelas, jawab lisan/tertulis, rekap agregat, koreksi hubungan, arsip dan pemulihan.
- Indeks skenario: kode salah, transkrip terputus, tanpa transkrip/penanda, proses gagal, tanggal ambigu/konflik, sumber tidak tersedia, dan kegagalan penghapusan eksternal.

Ini **prototype dengan data contoh**. Klik berpindah ke contoh hasil tindakan; bukan aplikasi dengan state data yang persisten. Form dan teks bisa diedit di mode Design, tetapi tidak menerima ketikan nyata dalam Present. Pengambilan audio, pemindaian QR, pilihan file, autentikasi, AI, pengiriman pertanyaan, dan sinkronisasi kalender memerlukan implementasi aplikasi. Preview foto/papan dan materi dibuat sebagai ilustrasi editable, bukan dokumen pengguna.

Overlay memiliki tombol Batal/Tutup. Posisi dan latar overlay menggunakan konfigurasi bawaan Figma; keduanya dapat disesuaikan pada tab Prototype. Tata letak dialog di preview browser tidak membuktikan posisi overlay aktual di Figma.

## Status pemeriksaan

Kode plugin, target navigasi, cakupan FR-001–030, kontras warna, dan pratinjau lokal telah diperiksa. Pengujian runtime menggunakan API double lokal untuk memeriksa pemanggilan API, tujuan prototype, ID hasil, pencegahan duplikasi, dan pelaporan kegagalan.

**Plugin belum dijalankan di Figma pada saat paket disiapkan.** Hasil native Figma, tipografi aktual, dan interaksi Present perlu diperiksa setelah langkah instalasi di atas. Jika ada masalah, simpan laporan hasil/error agar perbaikan dapat mengacu pada ID layer yang tepat.

## Referensi

- [Figma: membuat dan mengimpor plugin development](https://help.figma.com/hc/en-us/articles/360042786733-Create-a-classic-plugin-for-development)
- [Figma: plugin manifest](https://developers.figma.com/docs/plugins/manifest/)
- [Figma: prototype reactions](https://developers.figma.com/docs/plugins/api/properties/nodes-reactions/)
